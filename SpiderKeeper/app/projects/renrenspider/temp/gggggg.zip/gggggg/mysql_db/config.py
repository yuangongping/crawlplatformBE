DB_CONFIG_DEBUG = {
    'dbtype': 'mysql+pymysql',
    'host': '172.16.13.22',
    'dbname': 'map',
    'username': 'root',
    'password': 'root',
    'port': '3306',
    'charset': 'utf8mb4'
}
DB_CONFIG = {
    'dbtype': 'mysql+pymysql',
    'host': '172.16.119.3',
    'dbname': 'map',
    'username': 'root',
    'password': 'root',
    'port': '3306',
    'charset': 'utf8mb4'
}
